﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;

namespace Module01_Activity02
{
     class SharedStatic
    {
        public static readonly Color ButtonColor = Color.Black;
        public static readonly Color ButtonTextColor = Color.White;
    }
}
